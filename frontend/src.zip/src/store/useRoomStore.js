import create from "zustand";
import { immer } from "zustand/middleware/immer";

const useRoomStore = create(
  immer((set) => ({
    rooms: [],
    bookings: [],
    fetchRooms: async () => {
      const response = await fetch("http://localhost:5000/api/rooms");
      const rooms = await response.json();
      set((state) => {
        state.rooms = rooms;
      });
    },
    bookRoom: async ({ roomId, startDate, endDate }) => {
      set((state) => {
        state.bookings.push({
          roomId,
          startDate,
          endDate,
          status: "booked",
          id: state.bookings.length + 1,
        });
      });
    },
    getBookingById: (id) => (state) => {
      return state.bookings.find((b) => b.id === id);
    },
  }))
);

export default useRoomStore;
