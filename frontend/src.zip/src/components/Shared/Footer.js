import React from 'react';

function Footer() {
    return (
        <footer>
            <p>© 2024 Hotel Booking System, Inc.</p>
        </footer>
    );
}

export default Footer;
