import React, { useState } from "react";
import useRoomStore from "../../store/useRoomStore";

function BookingForm() {
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [roomId, setRoomId] = useState("");
  const bookRoom = useRoomStore((state) => state.bookRoom);

  const handleSubmit = async (event) => {
    event.preventDefault();
    await bookRoom({ roomId, startDate, endDate });
    setStartDate("");
    setEndDate("");
    setRoomId("");
  };

  return (
    <form onSubmit={handleSubmit}>
      <h3>Book a Room</h3>
      <input
        type="date"
        value={startDate}
        onChange={(e) => setStartDate(e.target.value)}
        required
      />
      <input
        type="date"
        value={endDate}
        onChange={(e) => setEndDate(e.target.value)}
        required
      />
      <input
        type="text"
        value={roomId}
        onChange={(e) => setRoomId(e.target.value)}
        placeholder="Room ID"
        required
      />
      <button type="submit">Book</button>
    </form>
  );
}

export default BookingForm;
