import React from "react";

function About() {
  return (
    <div>
      <h2>About Us</h2>
      <p>Learn more about our mission and services.</p>
    </div>
  );
}

export default About;
