import React from "react";

function Contact() {
  return (
    <div>
      <h2>Contact Us</h2>
      <p>Have questions? Contact us through the following methods.</p>
    </div>
  );
}

export default Contact;
