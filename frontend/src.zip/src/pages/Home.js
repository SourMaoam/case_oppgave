import React from "react";

function Home() {
  return (
    <div>
      <h2>Welcome to Our Hotel Booking Platform</h2>
      <p>Book your stay with us and enjoy world-class amenities.</p>
    </div>
  );
}

export default Home;
